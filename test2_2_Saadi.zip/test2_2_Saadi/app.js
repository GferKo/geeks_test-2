document.getElementById('calculateBtn').addEventListener('click', function() {
    const amount = parseFloat(document.getElementById('amount').value);
    const percentage = parseFloat(document.getElementById('percentage').value);

    if (isNaN(amount) || isNaN(percentage) || amount <= 0 || percentage < 0) {
        document.getElementById('result').innerText = 'Пожалуйста введите значения.';
        return;
    }

    const tip = (amount * percentage) / 100;
    const total = amount + tip;

    document.getElementById('result').innerText = `Итого: ${total.toFixed(2)}`;
});
